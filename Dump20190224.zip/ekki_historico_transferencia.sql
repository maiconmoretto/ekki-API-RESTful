-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: ekki
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `historico_transferencia`
--

DROP TABLE IF EXISTS `historico_transferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `historico_transferencia` (
  `id_historico_transferencia` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `id_destinatario` int(11) DEFAULT NULL,
  `valor` double DEFAULT NULL,
  `nome_destinatario` text,
  `numero_conta` text,
  `numero_cartao` text,
  `data_cadastro` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_historico_transferencia`),
  KEY `idusuario_idx` (`id_usuario`),
  KEY `id_destinatario_idx` (`id_destinatario`),
  CONSTRAINT `id_destinatario` FOREIGN KEY (`id_destinatario`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `idusuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historico_transferencia`
--

LOCK TABLES `historico_transferencia` WRITE;
/*!40000 ALTER TABLE `historico_transferencia` DISABLE KEYS */;
INSERT INTO `historico_transferencia` VALUES (157,1,7,0.01,'bruna','12345',NULL,'2019-02-24 19:07:34'),(159,1,7,0.01,'bruna','12345',NULL,'2019-02-24 19:12:12'),(161,1,7,0.01,'bruna','12345','12345678','2019-02-24 19:17:32'),(162,1,7,0.01,'bruna','12345','12345678','2019-02-24 19:19:58'),(163,1,7,10.01,'bruna','12345','12345678','2019-02-24 19:20:15');
/*!40000 ALTER TABLE `historico_transferencia` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-24 16:30:23
